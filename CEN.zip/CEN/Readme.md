Official Repository for CEN (MICCAI-2024).
