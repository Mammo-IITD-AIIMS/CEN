# TESTING

# AIIMS/INBREAST pluggable
# model_path = "./model_weights/pluggable/aiims/focalnet.pth"
# test_data_path ="/home/kshitiz/scratch/vision02/REMOTE_DATA/AIIMS/PAIR_DATASETS/TEST/"
# test_data_path ="/home/kshitiz/scratch/MAMMO/Negroni/INBREAST/PAIR_DATASETS/DATA/"

# model_path = "./model_weights/pluggable/aiims/dab_def.pth"
# test_data_path ="/home/kshitiz/scratch/vision02/FUSION_NET/DATA_BASELINES/DAB_DEFORM/AIIMS/TEST/"
# test_data_path ="/home/kshitiz/scratch/vision02/FUSION_NET/DATA_BASELINES/DAB_DEFORM/INBREAST/TEST/"

# model_path = "./model_weights/pluggable/aiims/dn_def.pth"
# test_data_path ="/home/kshitiz/scratch/vision02/FUSION_NET/DATA_BASELINES/DN_DEFORM/AIIMS/TEST/"
# test_data_path ="/home/kshitiz/scratch/vision02/FUSION_NET/DATA_BASELINES/DN_DEFORM/INBREAST/TEST/"

# model_path = "./model_weights/pluggable/aiims/yolo.pth"
# test_data_path ="/home/kshitiz/scratch/vision02/FUSION_NET/DATA_BASELINES/YOLO_v8/AIIMS/TEST/"
# test_data_path ="/home/kshitiz/scratch/vision02/FUSION_NET/DATA_BASELINES/YOLO_v8/INBREAST/TEST/"


# DDSM pluggable
# model_path = "./model_weights/pluggable/ddsm/focalnet.pth"
# test_data_path = "/home/kshitiz/scratch/vision02/REMOTE_DATA/DDSM/CBIS/PAIR_DATASETS/TEST_4k_coco/"

# model_path = "./model_weights/pluggable/ddsm/dat_def.pth"
# test_data_path ="/home/kshitiz/scratch/vision02/FUSION_NET/DATA_BASELINES/DAB_DEFORM/DDSM/TEST/"

# model_path = "./model_weights/pluggable/ddsm/dn_def.pth"
# test_data_path ="/home/kshitiz/scratch/vision02/FUSION_NET/DATA_BASELINES/DN_DEFORM/DDSM/TEST/"

# model_path = "/home/kshitiz/scratch/vision02/FUSION_NET/rebuttal/max_exps/YOLO_v8_DDSM/max_1e-06/94_epoch.pth"
# test_data_path ="/home/kshitiz/scratch/vision02/FUSION_NET/DATA_BASELINES/YOLO_v8/DDSM/TEST/"
